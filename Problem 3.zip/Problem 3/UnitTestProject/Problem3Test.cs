﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Problem_3;

namespace UnitTestProject
{
    [TestClass]
    public class Problem3Test
    {
        [TestMethod]
        public void LCA_CollectionTree_Test()
        {
            int expected = 2;
            CollectionTree tree = new CollectionTree();
            int actual = tree.LCA(8, 5);

            Assert.AreEqual(expected, actual, "Invalid Result");
        }

        [TestMethod]
        public void LCA_BinaryTree_Test()
        {
            int expected = 2;
            BinaryTree tree = new BinaryTree();
            int actual = tree.LCA(8, 5);

            Assert.AreEqual(expected, actual, "Invalid Result");
        }
    }
}
