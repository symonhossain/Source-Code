﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_3
{
    class Program
    {

        static void Main(string[] args)
        {
            CollectionTree colTree = new CollectionTree();

            Console.WriteLine("5, 7 - " + colTree.LCA(5, 7).ToString());
            Console.WriteLine("8, 5 - " + colTree.LCA(8, 5).ToString());
            //Console.WriteLine("4, 5 - " + colTree.LCA(4, 5).ToString());
            //Console.WriteLine("8, 9 - " + colTree.LCA(8, 9).ToString());
            Console.WriteLine("8, 4 - " + colTree.LCA(8, 4).ToString());
            Console.WriteLine("4, 8 - " + colTree.LCA(4, 8).ToString());
            //Console.WriteLine("6, 7 - " + colTree.LCA(6, 7).ToString());
            //Console.WriteLine("3, 7 - " + colTree.LCA(3, 7).ToString());
            //Console.WriteLine("8, 7 - " + colTree.LCA(8, 7).ToString());
            //Console.WriteLine("8, 3 - " + colTree.LCA(8, 3).ToString());
            //Console.WriteLine("5, 6 - " + colTree.LCA(5, 6).ToString());
            //Console.WriteLine("2, 3 - " + colTree.LCA(2, 3).ToString());
            //Console.WriteLine("2, 1 - " + colTree.LCA(2, 1).ToString());

            BinaryTree binaryTree = new BinaryTree();
            Console.WriteLine("LCA(5, 7) = " + binaryTree.LCA(5, 7).ToString());
            Console.WriteLine("LCA(8, 5) = " + binaryTree.LCA(8, 5).ToString());
            Console.WriteLine("LCA(8, 4) = " + binaryTree.LCA(8, 4).ToString());
            Console.WriteLine("LCA(4, 8) = " + binaryTree.LCA(4, 8).ToString());

            Console.ReadKey();
        }
    }

}
