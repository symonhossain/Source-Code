﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_3
{
    class Node
    {
        int _value;
        int _parent;
        List<Node> _childs;

        public Node(int value, int parent)
        {
            this._value = value;
            this._parent = parent;

            this._childs = new List<Node>();
        }

        public int Value
        {
            get { return this._value; }
        }
        public int Parent
        {
            get { return this._parent; }
        }
        public List<Node> Childs
        {
            get { return this._childs; }
        }
    }

    public class CollectionTree
    {
        static Node _root;
        static int _parent;
        static List<int> _path1 = new List<int>();
        static List<int> _path2 = new List<int>();

        public CollectionTree()
        {
            _root = new Node(1, 0);
            _root.Childs.Add(new Node(2, 1));
            _root.Childs[0].Childs.Add(new Node(4, 2));
            _root.Childs[0].Childs[0].Childs.Add(new Node(8, 4));
            _root.Childs[0].Childs[0].Childs.Add(new Node(9, 4));

            _root.Childs[0].Childs.Add(new Node(5, 2));

            _root.Childs.Add(new Node(3, 1));
            _root.Childs[1].Childs.Add(new Node(6, 3));
            _root.Childs[1].Childs.Add(new Node(7, 3));
        }

        // This function returns pointer to LCA of two given 
        // values n1 and n2. 
        public int LCA(int node1, int node2)
        {
            _path1.Clear();
            _path2.Clear();

            _parent = 0;
            FindPath(_root, node1, _path1);
            _parent = 0;
            FindPath(_root, node2, _path2);

            int lca = 0;
            foreach (int i in _path1)
            {
                if (i == node2)
                {
                    lca = i;
                    break;
                }

                foreach (int j in _path2)
                {
                    if (j == node1)
                    {
                        lca = j;
                        break;
                    }
                    if (i == j)
                    {
                        lca = i;
                        break;
                    }
                }
                if (lca > 0) { break; }
            }

            return lca;
        }

        // Finds lca of given value under the subtree rooted
        // and stores in the path list
        static void FindPath(Node node, int n, List<int> path)
        {
            foreach (Node item in node.Childs)
            {
                if (item.Value == n)
                {
                    _parent = item.Parent;
                    path.Add(item.Parent);
                    return;
                }
                else
                {
                    FindPath(item, n, path);
                }

                if (_parent > 0)
                {
                    if (item.Value == _parent)
                    {
                        _parent = item.Parent;
                        path.Add(item.Parent);
                    }
                }
            }
        }
    }
}
