﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_3
{
    class BinaryNode
    {
        public int data;
        public BinaryNode left, right;

        public BinaryNode(int item)
        {
            data = item;
            left = right = null;
        }
    }

    public class BinaryTree
    {
        BinaryNode root;
        static bool v1 = false, v2 = false;

        public BinaryTree()
        {
            this.root = new BinaryNode(1);
            this.root.left = new BinaryNode(2);
            this.root.right = new BinaryNode(3);
            this.root.left.left = new BinaryNode(4);
            this.root.left.right = new BinaryNode(5);
            this.root.right.left = new BinaryNode(6);
            this.root.right.right = new BinaryNode(7);
            this.root.left.left.left = new BinaryNode(8);
            this.root.left.left.right = new BinaryNode(9);
        }

        // This function returns pointer to LCA of two given 
        // values n1 and n2. 
        // v1 is set as true by this function if n1 is found 
        // v2 is set as true by this function if n2 is found 
        BinaryNode LCAUtil(BinaryNode node, int n1, int n2)
        {
            if (node == null)
                return null;

            //Store result in temp, in case of key match so that we can search for other key also. 
            BinaryNode temp = null;

            // If either n1 or n2 matches with root's key, report the presence 
            // by setting v1 or v2 as true and return root (Note that if a key 
            // is ancestor of other, then the ancestor key becomes LCA) 
            if (node.data == n1)
            {
                v1 = true;
                temp = node;
            }
            if (node.data == n2)
            {
                v2 = true;
                temp = node;
            }

            // Look for keys in left and right subtrees 
            BinaryNode left_lca = LCAUtil(node.left, n1, n2);
            BinaryNode right_lca = LCAUtil(node.right, n1, n2);

            if (temp != null)
                return temp;

            // If both of the above calls return Non-NULL, then one key 
            // is present in once subtree and other is present in other, 
            // So this node is the LCA 
            if (left_lca != null && right_lca != null)
                return node;

            // Otherwise check if left subtree or right subtree is LCA 
            return (left_lca != null) ? left_lca : right_lca;
        }

        // Finds lca of n1 and n2 under the subtree rooted with 'node' 
        public int LCA(int n1, int n2)
        {
            // Initialize n1 and n2 as not visited 
            v1 = false;
            v2 = false;

            // Find lca of n1 and n2 using the technique discussed above 
            BinaryNode lca = LCAUtil(root, n1, n2);

            // Return LCA only if both n1 and n2 are present in tree 
            if (v1 && v2)
                return lca.data;

            // Else return 0
            return 0;
        }
    }
}
