﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Problem_1;

namespace UnitTestProject
{
    [TestClass]
    public class Problem1UnitTest
    {
        [TestMethod]
        public void TestOutputResult()
        {
            string expected = "key1 1" + Environment.NewLine +
                              "key2 1" + Environment.NewLine +
                              "key3 2" + Environment.NewLine +
                              "key4 2" + Environment.NewLine +
                              "key5 3" + Environment.NewLine;

            JSONOblect json = new JSONOblect();
            string actual = json.outputResult;

            Assert.AreEqual(expected, actual, "Invalid Result");
        }
    }
}
