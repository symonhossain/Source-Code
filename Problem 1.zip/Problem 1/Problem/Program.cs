﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Problem_1
{
    static class Program
    {
        static void Main(string[] args)
        {
            JSONOblect json = new JSONOblect();
            Console.Write(json.outputResult);
            Console.ReadKey();
        }
    }

    public class JSONOblect
    {
        string a = "{" +
                '"' + "key1" + '"' + ":" + '"' + "1" + '"' + "," +
                '"' + "key2" + '"' + ": {" +
                        '"' + "key3" + '"' + ":" + '"' + "1" + '"' + "," +
                        '"' + "key4" + '"' + ": {" +
                                '"' + "key5" + '"' + ":" + '"' + "4" + '"' +
                            "}" +
                    "}" +
            "}";

        Dictionary<string, object> dictionary;

        public string outputResult;

        public JSONOblect()
        {
            outputResult = string.Empty;
            dictionary = DeserializeJson(a);
            Recursion(dictionary, 1);
        }
        Dictionary<string, object> DeserializeJson(string json)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            Dictionary<string, object> dictionary = serializer.Deserialize<Dictionary<string, object>>(json);
            return dictionary;
        }
        void Recursion(Dictionary<string, object> dic, int level)
        {
            foreach (KeyValuePair<string, object> entry in dic)
            {
                if (entry.Value is Dictionary<string, object>)
                {
                    outputResult += entry.Key + " " + level.ToString() + Environment.NewLine;
                    Recursion((Dictionary<string, object>)entry.Value, level + 1);
                }
                else
                {
                    outputResult += entry.Key + " " + level.ToString() + Environment.NewLine;
                }
            }
        }
    }
}
