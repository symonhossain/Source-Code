﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Problem_2
{
    static class Program
    {
        static void Main(string[] args)
        {
            JSONOblect json = new JSONOblect();
            Console.Write(json.outputResult);

            Console.ReadKey();
        }
    }

    public class Person
    {
        string _first_name, _last_name;
        object _father;

        public Person(string first_name, string last_name, object father)
        {
            this._first_name = first_name;
            this._last_name = last_name;
            this._father = father;
        }

        public string first_name
        {
            get { return _first_name; }
        }
        public string last_name
        {
            get { return _last_name; }
        }
        public object father
        {
            get { return _father; }
        }
    }
    public class JSONOblect
    {
        string a = "{" +
                        '"' + "key1" + '"' + ":" + '"' + "1" + '"' + "," +
                        '"' + "key2" + '"' + ": {" +
                                '"' + "key3" + '"' + ":" + '"' + "1" + '"' + "," +
                                '"' + "key4" + '"' + ": {" +
                                        '"' + "key5" + '"' + ":" + '"' + "4" + '"' + "," +
                                        '"' + "user" + '"' + ":" + "person_b" +
                                    "}" +
                            "}" +
                    "}";

        Dictionary<string, object> dictionary;

        public string outputResult;

        public JSONOblect()
        {
            outputResult = string.Empty;

            Person person_a = new Person("User", "1", "none");
            Person person_b = new Person("User", "1", person_a);
            string person_json = SerializeJson(person_b);
            a = a.Replace("person_b", person_json);

            dictionary = DeserializeJson(a);
            Recursion(dictionary, 1);
        }
        Dictionary<string, object> DeserializeJson(string json)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            Dictionary<string, object> dictionary = serializer.Deserialize<Dictionary<string, object>>(json);
            return dictionary;
        }
        string SerializeJson(object p)
        {
            return new JavaScriptSerializer().Serialize(p);
        }
        void Recursion(Dictionary<string, object> dic, int level)
        {
            foreach (KeyValuePair<string, object> entry in dic)
            {
                if (entry.Value is Dictionary<string, object>)
                {
                    outputResult += entry.Key + " " + level.ToString() + Environment.NewLine;
                    Recursion((Dictionary<string, object>)entry.Value, level + 1);
                }
                else
                {
                    outputResult += entry.Key + " " + level.ToString() + Environment.NewLine;
                }
            }
        }
    }
}
