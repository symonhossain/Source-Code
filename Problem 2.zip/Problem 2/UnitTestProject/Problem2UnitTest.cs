﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Problem_2;

namespace UnitTestProject
{
    [TestClass]
    public class Problem2UnitTest
    {
        [TestMethod]
        public void TestOutputResult()
        {
            string expected = "key1 1" + Environment.NewLine +
                      "key2 1" + Environment.NewLine +
                      "key3 2" + Environment.NewLine +
                      "key4 2" + Environment.NewLine +
                      "key5 3" + Environment.NewLine +
                      "user 3" + Environment.NewLine +
                      "first_name 4" + Environment.NewLine +
                      "last_name 4" + Environment.NewLine +
                      "father 4" + Environment.NewLine +
                      "first_name 5" + Environment.NewLine +
                      "last_name 5" + Environment.NewLine +
                      "father 5" + Environment.NewLine;

            JSONOblect json = new JSONOblect();
            string actual = json.outputResult;

            Assert.AreEqual(expected, actual, "Invalid Result");
        }
    }
}
